from django.db import models
from django.utils import timezone
from datetime import date
from django.contrib.auth.models import User

# Create your models here.

class Usuario(models.Model):
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    cedula = models.CharField(max_length=10)
    email = models.EmailField()
    telefono = models.CharField(max_length=30, null=True, blank=True)
    contrasena = models.CharField(max_length=8)


class Concierto(models.Model):
    nombre = models.CharField(max_length=255)
    descripcion = models.CharField(max_length=255)
    fecha = models.DateTimeField()
    lugar = models.CharField(max_length=255)
    precio_ticket = models.DecimalField(max_digits=10, decimal_places=2)
    capacidad = models.IntegerField()

class Ticket(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    concierto = models.ForeignKey(Concierto, on_delete=models.CASCADE)
    fecha_compra = models.DateTimeField()
