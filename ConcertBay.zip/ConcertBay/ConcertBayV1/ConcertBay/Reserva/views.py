from django.shortcuts import render
from models import *
from django.shortcuts import HttpResponse
from django.views.generic import TemplateView
from django.shortcuts import render
from .models import Concierto

# Create your views here.

def home(request):
    conciertos = Concierto.objects.all()
    return render(request, 'home.html', {'conciertos': conciertos})


def getInfoConciertoById(request, id_concierto):
    concierto = Concierto.objects.get(id=id_concierto)
    result_layout = f'<h3>Concierto:{concierto.nombre}, Descripcion: {concierto.descripcion}, Precio: {concierto.precio_ticket}'
    return HttpResponse(result_layout)


def getUsuarioById(request, id_usuario):
    usuario = Usuario.objects.get(id=id_usuario)
    result = f'<h3>Usuario:{usuario.nombre}, Apellido: {usuario.apellido}, Email: {usuario.email}'
    return HttpResponse(result)

#class MainView(TemplateView):
 #   template_name= 'home.html'